<?php

namespace Utd\Family\Console;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;

class UninstallFamilyCommand extends Command
{
    /**
     * @var string
     */
    protected $signature = 'family:uninstall 
                            {--force : تنفيذ بدون تأكيد}';

    /**
     * @var string
     */
    protected $description = 'إلغاء تثبيت حزمة Family دون حذف أي بيانات من قاعدة البيانات';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $this->warn('⚠️  تحذير: هذا الأمر سيعطل حزمة Family دون أي حذف للبيانات.');
        $this->newLine();

        if (! $this->option('force')) {
            if (! $this->confirm('هل أنت متأكد من رغبتك في إلغاء تثبيت حزمة Family؟')) {
                $this->info('تم إلغاء العملية.');
                return Command::SUCCESS;
            }
        }

        $this->info('🗑️  بدء إلغاء التثبيت...');
        $this->line('ℹ️ لن يتم حذف أي جداول أو أعمدة. قم بإزالة البيانات يدويًا إذا لزم الأمر.');

        $this->removeFromComposer();

        $this->newLine();
        $this->info('✅ تم إلغاء تثبيت حزمة Family بنجاح!');
        $this->warn('📝 نفذ composer dump-autoload لإكمال الإزالة.');

        return Command::SUCCESS;
    }

   

    protected function removeFromComposer()
    {
        $path = base_path('composer.json');
        if (! File::exists($path)) {
            return;
        }

        $composer = json_decode(File::get($path), true);
        if (isset($composer['require']['utd/family'])) {
            unset($composer['require']['utd/family']);
            File::put($path, json_encode($composer, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        }
    }

}
