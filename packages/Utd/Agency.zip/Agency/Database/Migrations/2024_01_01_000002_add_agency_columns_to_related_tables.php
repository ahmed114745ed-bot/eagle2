<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * الأعمدة المتعلقة بالوكالات في الجداول الأخرى
     * يتم إضافتها عند تثبيت الحزمة وإزالتها عند إزالة الحزمة
     */
    
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // 1. جدول users - إضافة أعمدة الوكالات
        if (Schema::hasTable('users')) {
            Schema::table('users', function (Blueprint $table) {
                if (!Schema::hasColumn('users', 'agency_id')) {
                    $table->unsignedInteger('agency_id')->nullable()->default(0)->after('family_id');
                }
                if (!Schema::hasColumn('users', 'type_user')) {
                    $table->integer('type_user')->default(0)->after('agency_id')->comment('0:normal, 1:owner, 2:admin, 3:host, 4:professional');
                }
                if (!Schema::hasColumn('users', 'is_manger')) {
                    $table->boolean('is_manger')->default(false)->after('type_user');
                }
                if (!Schema::hasColumn('users', 'is_host')) {
                    $table->unsignedTinyInteger('is_host')->nullable()->default(0)->after('is_manger');
                }
            });
            
            // إضافة index لـ agency_id
            $this->addIndexIfNotExists('users', 'agency_id');
        }
        
        // 2. جدول gift_logs - إضافة agency_id
        if (Schema::hasTable('gift_logs')) {
            Schema::table('gift_logs', function (Blueprint $table) {
                if (!Schema::hasColumn('gift_logs', 'agency_id')) {
                    $table->unsignedInteger('agency_id')->nullable()->after('exp');
                }
            });
            
            // إضافة index لـ agency_id
            $this->addIndexIfNotExists('gift_logs', 'agency_id');
        }
        
        // 3. جدول charges - إضافة agency_id
        if (Schema::hasTable('charges')) {
            Schema::table('charges', function (Blueprint $table) {
                if (!Schema::hasColumn('charges', 'agency_id')) {
                    $table->integer('agency_id')->nullable()->after('type');
                }
            });
        }
        
        // 4. جدول user_sallaries - إضافة user_agency_id
        if (Schema::hasTable('user_sallaries')) {
            Schema::table('user_sallaries', function (Blueprint $table) {
                if (!Schema::hasColumn('user_sallaries', 'user_agency_id')) {
                    $table->unsignedBigInteger('user_agency_id')->default(0)->after('user_id');
                }
            });
        }
        
        // 5. جدول usd_transfers - إضافة agency_id
        if (Schema::hasTable('usd_transfers')) {
            Schema::table('usd_transfers', function (Blueprint $table) {
                if (!Schema::hasColumn('usd_transfers', 'agency_id')) {
                    $table->unsignedBigInteger('agency_id')->nullable()->after('user_id');
                }
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // 1. إزالة أعمدة الوكالات من users
        if (Schema::hasTable('users')) {
            Schema::table('users', function (Blueprint $table) {
                $this->dropColumnIfExists($table, 'users', 'agency_id');
                $this->dropColumnIfExists($table, 'users', 'type_user');
                $this->dropColumnIfExists($table, 'users', 'is_manger');
                $this->dropColumnIfExists($table, 'users', 'is_host');
            });
        }
        
        // 2. إزالة agency_id من gift_logs
        if (Schema::hasTable('gift_logs')) {
            Schema::table('gift_logs', function (Blueprint $table) {
                $this->dropColumnIfExists($table, 'gift_logs', 'agency_id');
            });
        }
        
        // 3. إزالة agency_id من charges
        if (Schema::hasTable('charges')) {
            Schema::table('charges', function (Blueprint $table) {
                $this->dropColumnIfExists($table, 'charges', 'agency_id');
            });
        }
        
        // 4. إزالة user_agency_id من user_sallaries
        if (Schema::hasTable('user_sallaries')) {
            Schema::table('user_sallaries', function (Blueprint $table) {
                $this->dropColumnIfExists($table, 'user_sallaries', 'user_agency_id');
            });
        }
        
        // 5. إزالة agency_id من usd_transfers
        if (Schema::hasTable('usd_transfers')) {
            Schema::table('usd_transfers', function (Blueprint $table) {
                $this->dropColumnIfExists($table, 'usd_transfers', 'agency_id');
            });
        }
    }
    
    /**
     * إضافة index إذا لم يكن موجوداً
     */
    private function addIndexIfNotExists(string $table, string $column): void
    {
        $indexName = "{$table}_{$column}_index";
        $indexes = collect(\DB::select("SHOW INDEX FROM {$table}"))->pluck('Key_name')->toArray();
        
        if (!in_array($indexName, $indexes) && !in_array($column, $indexes)) {
            Schema::table($table, function (Blueprint $table) use ($column) {
                $table->index($column);
            });
        }
    }
    
    /**
     * إزالة عمود إذا كان موجوداً
     */
    private function dropColumnIfExists(Blueprint $table, string $tableName, string $column): void
    {
        if (Schema::hasColumn($tableName, $column)) {
            // إزالة index أولاً إذا كان موجوداً
            $indexName = "{$tableName}_{$column}_index";
            try {
                $table->dropIndex($indexName);
            } catch (\Exception $e) {
                // Index قد لا يكون موجوداً
            }
            
            $table->dropColumn($column);
        }
    }
};
