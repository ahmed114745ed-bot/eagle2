<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * جداول الوكالات الرئيسية
     * يتم إنشاؤها عند تثبيت الحزمة
     */
    
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // 1. جدول الوكالات الرئيسي
        if (!Schema::hasTable('agencies')) {
            Schema::create('agencies', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('notice')->nullable();
                $table->string('phone')->nullable();
                $table->string('phone_code')->nullable();
                $table->string('img')->nullable();
                $table->unsignedBigInteger('app_owner_id')->comment('owner user id');
                $table->tinyInteger('type')->default(1)->comment('1: host, 2: shipping');
                $table->decimal('target_usd', 15, 2)->default(0);
                $table->boolean('is_frozen')->default(false);
                $table->integer('bd_id')->nullable();
                $table->unsignedBigInteger('country_id')->nullable();
                $table->unsignedBigInteger('region_id')->nullable();
                $table->timestamps();
                $table->softDeletes();
                
                $table->index('app_owner_id');
                $table->index('type');
                $table->index('bd_id');
            });
        }
        
        // 2. جدول طلبات الانضمام للوكالة
        if (!Schema::hasTable('agency_join_requests')) {
            Schema::create('agency_join_requests', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('user_id');
                $table->unsignedBigInteger('agency_id');
                $table->unsignedTinyInteger('status')->default(0)->comment('0=pending 1=accepted 2=denied');
                $table->unsignedBigInteger('change_status_admin_id')->nullable()->default(0)->comment('admin that accept or denied');
                $table->string('whatsapp')->nullable();
                $table->timestamps();
                
                $table->index('user_id');
                $table->index('agency_id');
                $table->index('status');
            });
        }
        
        // 3. جدول المستخدمين المنضمين للوكالات
        if (!Schema::hasTable('users_joined_agencies')) {
            Schema::create('users_joined_agencies', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('agency_id');
                $table->unsignedBigInteger('user_id');
                $table->integer('type')->comment('1:owner, 2:host');
                $table->dateTime('join_date');
                $table->dateTime('leave_date')->nullable();
                $table->unsignedBigInteger('kicked_by_app_id')->nullable();
                $table->unsignedBigInteger('kicked_by_admin_id')->nullable();
                $table->tinyInteger('status')->default(1)->comment('1:active, 0:inactive');
                $table->timestamps();
                
                $table->index('agency_id');
                $table->index('user_id');
                $table->index(['agency_id', 'user_id', 'leave_date']);
            });
        }
        
        // 4. جدول أهداف المستخدمين
        if (!Schema::hasTable('user_target')) {
            Schema::create('user_target', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('user_id');
                $table->unsignedInteger('agency_id')->nullable();
                $table->integer('add_month');
                $table->integer('add_year');
                $table->decimal('target_usd', 15, 2)->default(0);
                $table->decimal('target_hours', 10, 2)->default(0);
                $table->integer('target_days')->default(0);
                $table->decimal('target_agency_share', 5, 2)->default(0);
                $table->decimal('user_diamonds', 15, 2)->default(0);
                $table->decimal('user_hours', 10, 2)->default(0);
                $table->integer('user_days')->default(0);
                $table->decimal('user_obtain', 15, 2)->default(0);
                $table->decimal('agency_obtain', 15, 2)->default(0);
                $table->decimal('next_diamond', 15, 2)->default(0);
                $table->timestamps();
                
                $table->index('user_id');
                $table->index('agency_id');
                $table->index(['add_month', 'add_year']);
            });
        }
        
        // 5. جدول رواتب المستخدمين
        if (!Schema::hasTable('user_sallaries')) {
            Schema::create('user_sallaries', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('user_id');
                $table->unsignedBigInteger('user_agency_id')->default(0);
                $table->decimal('agency_sallary', 15, 6)->default(0);
                $table->integer('add_month');
                $table->integer('add_year');
                $table->timestamps();
                
                $table->index('user_id');
                $table->index('user_agency_id');
            });
        }
        
        // 6. جدول رواتب الوكالات
        if (!Schema::hasTable('agency_sallaries')) {
            Schema::create('agency_sallaries', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('agency_id')->default(0);
                $table->decimal('agency_sallary', 15, 6)->default(0);
                $table->integer('add_month');
                $table->integer('add_year');
                $table->decimal('salary', 15, 2)->default(0);
                $table->timestamps();
                
                $table->index('agency_id');
            });
        }
        
        // 7. جدول باقات الوكالات
        if (!Schema::hasTable('agency_packs')) {
            Schema::create('agency_packs', function (Blueprint $table) {
                $table->id();
                $table->bigInteger('agency_id');
                $table->bigInteger('user_id');
                $table->bigInteger('ware_id');
                $table->integer('count')->default(1);
                $table->timestamps();
                
                $table->index('agency_id');
                $table->index('user_id');
            });
        }
        
        // 8. جدول وظائف المستخدمين في الوكالة
        if (!Schema::hasTable('agency_user_jobs')) {
            Schema::create('agency_user_jobs', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('agency_id');
                $table->unsignedBigInteger('user_id');
                $table->string('job_type')->comment('admin, moderator, etc');
                $table->timestamps();
                
                $table->index(['agency_id', 'user_id']);
            });
        }
        
        // 9. جدول السجلات/التاريخ
        if (!Schema::hasTable('histories')) {
            Schema::create('histories', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('agency_id');
                $table->unsignedBigInteger('from_user_id');
                $table->unsignedBigInteger('to_user_id');
                $table->string('type');
                $table->decimal('amount', 15, 2)->default(0);
                $table->text('note')->nullable();
                $table->timestamps();
                
                $table->index('agency_id');
            });
        }
        
        // 10. جدول الأهداف العامة
        if (!Schema::hasTable('targets')) {
            Schema::create('targets', function (Blueprint $table) {
                $table->id();
                $table->integer('level')->default(0);
                $table->decimal('usd', 15, 2)->default(0);
                $table->decimal('agency_share', 5, 2)->default(0);
                $table->decimal('user_share', 5, 2)->default(0);
                $table->decimal('hours', 10, 2)->default(0);
                $table->integer('days')->default(0);
                $table->timestamps();
            });
        }
        
        // 11. جدول مديري الوكالات المحذوفين
        if (!Schema::hasTable('agency_manger_deleteds')) {
            Schema::create('agency_manger_deleteds', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('agency_id');
                $table->unsignedBigInteger('user_id');
                $table->unsignedBigInteger('deleted_by_admin_id')->nullable();
                $table->text('reason')->nullable();
                $table->timestamps();
                
                $table->index('agency_id');
            });
        }
        
        // 12. جدول سحب مديري الوكالات
        if (!Schema::hasTable('agency_manger_pulling_out')) {
            Schema::create('agency_manger_pulling_out', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('agency_id');
                $table->unsignedBigInteger('user_id');
                $table->decimal('amount', 15, 2)->default(0);
                $table->string('status')->default('pending');
                $table->timestamps();
                
                $table->index('agency_id');
            });
        }
        
        // 13. جدول لوحة تحكم مديري الوكالات
        if (!Schema::hasTable('agency_manger_app_dash')) {
            Schema::create('agency_manger_app_dash', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('agency_id');
                $table->unsignedBigInteger('user_id');
                $table->string('permission')->nullable();
                $table->timestamps();
                
                $table->index(['agency_id', 'user_id']);
            });
        }
        
        // 14. جدول تغيير مديري الوكالات
        if (!Schema::hasTable('change_agency_mangers')) {
            Schema::create('change_agency_mangers', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('agency_id');
                $table->unsignedBigInteger('from_user_id');
                $table->unsignedBigInteger('to_user_id');
                $table->unsignedBigInteger('changed_by_admin_id')->nullable();
                $table->text('reason')->nullable();
                $table->timestamps();
                
                $table->index('agency_id');
            });
        }
        
        // 15. جدول نسب مديري الوكالات
        if (!Schema::hasTable('percentage_agency_manger')) {
            Schema::create('percentage_agency_manger', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('agency_id');
                $table->decimal('percentage', 5, 2)->default(0);
                $table->timestamps();
                
                $table->index('agency_id');
            });
        }
        
        // 16. جدول رواتب BD للهوستات
        if (!Schema::hasTable('bd_agency_host_sallaries')) {
            Schema::create('bd_agency_host_sallaries', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('bd_id');
                $table->unsignedBigInteger('agency_id');
                $table->unsignedBigInteger('user_id');
                $table->decimal('salary', 15, 2)->default(0);
                $table->integer('add_month');
                $table->integer('add_year');
                $table->timestamps();
                
                $table->index(['bd_id', 'agency_id']);
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // حذف الجداول بترتيب عكسي لتجنب مشاكل الـ foreign keys
        Schema::dropIfExists('bd_agency_host_sallaries');
        Schema::dropIfExists('percentage_agency_manger');
        Schema::dropIfExists('change_agency_mangers');
        Schema::dropIfExists('agency_manger_app_dash');
        Schema::dropIfExists('agency_manger_pulling_out');
        Schema::dropIfExists('agency_manger_deleteds');
        Schema::dropIfExists('targets');
        Schema::dropIfExists('histories');
        Schema::dropIfExists('agency_user_jobs');
        Schema::dropIfExists('agency_packs');
        Schema::dropIfExists('agency_sallaries');
        Schema::dropIfExists('user_sallaries');
        Schema::dropIfExists('user_target');
        Schema::dropIfExists('users_joined_agencies');
        Schema::dropIfExists('agency_join_requests');
        Schema::dropIfExists('agencies');
    }
};
