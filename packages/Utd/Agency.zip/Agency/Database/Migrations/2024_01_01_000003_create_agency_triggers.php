<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Triggers الخاصة بتحديث أهداف الوكالات
     */
    
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // تأكد من وجود الجداول المطلوبة
        if (!Schema::hasTable('agencies') || !Schema::hasTable('user_target')) {
            return;
        }
        
        // حذف الـ triggers القديمة إذا كانت موجودة
        DB::unprepared('DROP TRIGGER IF EXISTS `update_agrncy_target`');
        DB::unprepared('DROP TRIGGER IF EXISTS `update_agrncy_target1`');
        DB::unprepared('DROP TRIGGER IF EXISTS `update_agrncy_target_after_change_agency`');
        
        // Trigger لتحديث target الوكالة بعد تحديث user_target
        DB::unprepared('
            CREATE TRIGGER `update_agrncy_target` AFTER UPDATE ON `user_target` 
            FOR EACH ROW 
            UPDATE agencies SET target_usd = (
                SELECT COALESCE(SUM(agency_obtain), 0) 
                FROM user_target 
                WHERE agency_id = NEW.agency_id 
                AND add_month = MONTH(CURDATE()) 
                AND add_year = YEAR(CURDATE())
            ) WHERE id = NEW.agency_id
        ');
        
        // Trigger لتحديث target الوكالة القديمة بعد تغيير الوكالة
        DB::unprepared('
            CREATE TRIGGER `update_agrncy_target_after_change_agency` AFTER UPDATE ON `user_target` 
            FOR EACH ROW 
            UPDATE agencies SET target_usd = (
                SELECT COALESCE(SUM(agency_obtain), 0) 
                FROM user_target 
                WHERE agency_id = OLD.agency_id 
                AND add_month = MONTH(CURDATE()) 
                AND add_year = YEAR(CURDATE())
            ) WHERE id = OLD.agency_id
        ');
        
        // Trigger لتحديث target الوكالة بعد إضافة user_target جديد
        DB::unprepared('
            CREATE TRIGGER `update_agrncy_target1` AFTER INSERT ON `user_target` 
            FOR EACH ROW 
            UPDATE agencies SET target_usd = (
                SELECT COALESCE(SUM(agency_obtain), 0) 
                FROM user_target 
                WHERE agency_id = NEW.agency_id 
                AND add_month = MONTH(CURDATE()) 
                AND add_year = YEAR(CURDATE())
            ) WHERE id = NEW.agency_id
        ');
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // حذف الـ triggers
        DB::unprepared('DROP TRIGGER IF EXISTS `update_agrncy_target`');
        DB::unprepared('DROP TRIGGER IF EXISTS `update_agrncy_target1`');
        DB::unprepared('DROP TRIGGER IF EXISTS `update_agrncy_target_after_change_agency`');
    }
};
